#include "main.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For sleep()

int main(void) {
  // Set LED pins as output
  pinMode(PA5, OUTPUT);
  pinMode(PA6, OUTPUT);
  pinMode(PA7, OUTPUT);

  while (1) {
    // Toggle all LEDs
    digitalWrite(PA6, !digitalRead(PA6));
    digitalWrite(PA11, !digitalRead(PA11));
    digitalWrite(PA12, !digitalRead(PA12));

    // Delay 1 second
    delay(1000);
  }

  return 0;
}
