#ifndef MAIN_H
#define MAIN_H

// Wokwi uses Arduino-style API, even for STM32 simulation
#include <Arduino.h>

// Define pin numbers
#define PA5  D13
#define PA6  D12
#define PA7  D11

#endif
