// Reference https://docs.wokwi.com/parts/wokwi-ntc-temperature-sensor

#define sensorPin A0
#define BETA 3950

int ledArray[] = {4,5,6,7,8,9,10,11,12,13};

void setup() {
  pinMode(sensorPin, INPUT);
  for(int i=0;i<10;i++){
    pinMode(ledArray[i],OUTPUT);
  }
    // initialize LEDs and sensor pin
}

void loop() {
  for(int i=0;i<10;i++){
    digitalWrite(ledArray[i],LOW);
  }
  int ledlights=0;
  int analogValue=analogRead(sensorPin);
  float celsius = 1 / (log(1 / (1023. / analogValue - 1)) / BETA + 1.0 / 298.15) - 273.15;
  float mintemp=-24.0;
  float maxtemp=80.0;
  if(celsius<=mintemp){
    ledlights=0;
  }
  else if(celsius>=maxtemp){
    ledlights=10;
  }
  else{
    ledlights=round((celsius-mintemp)/(maxtemp-mintemp)*10);
  }
  for(int i=0;i<ledlights;i++){
    digitalWrite(ledArray[i],i<ledlights?HIGH:LOW);
  }
  // Read the sensor value , calculate the temperature, light up the leds
  delay(100); // this speeds up the simulation
}
