#include <avr/io.h>
#include <avr/interrupt.h>

volatile uint8_t interrupt_count = 0;

ISR(TIMER2_COMPA_vect)
{
    // Toggle D12 (PB4) every compare match interrupt (~1ms)
    PORTB ^= (1 << PB4);

    // Increment interrupt count
    interrupt_count++;

    // Toggle D13 (PB5) every 125 interrupts (~1 second)
    if (interrupt_count >= 125)
    {
        PORTB ^= (1 << PB5);   // Toggle D13
        interrupt_count = 0;   // Reset count
    }
}

int main(void)
{
    // --------------------------
    // GPIO Setup
    // --------------------------
    // Set PB4 (D12) and PB5 (D13) as outputs
    DDRB |= (1 << PB4) | (1 << PB5);

    // --------------------------
    // Timer2 Setup (CTC Mode)
    // --------------------------

    // CTC mode: WGM21 = 1, WGM20 = 0
    TCCR2A |= (1 << WGM21);
    TCCR2A &= ~(1 << WGM20);

    // Set compare match value to 124
    // Timer resets after counting from 0 to 124 (i.e. 125 ticks)
    OCR2A = 124;

    // Prescaler = 1024: CS22=1, CS21=0, CS20=1
    TCCR2B |= (1 << CS22) | (1 << CS20);
    TCCR2B &= ~(1 << CS21);

    // Enable Output Compare Match A Interrupt
    TIMSK2 |= (1 << OCIE2A);

    // --------------------------
    // Enable Global Interrupts
    // --------------------------
    sei();

    // --------------------------
    // Main Loop
    // --------------------------
    while (1)
    {
        // All the action happens in the ISR.
        // Main loop stays responsive and ready for other tasks.
    }

    return 0;
}
