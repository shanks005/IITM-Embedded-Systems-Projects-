#define colorBtn 6
#define durationBtn 7
#define redpin 13
#define greenpin 12
#define bluepin 11

bool colors[][3] = {
  {1,1,1}, {1,0,0}, {0,1,0}, {0,0,1},
  {0,1,1}, {1,1,0}, {1,0,1}, {0,0,0}
};

char* colorNames[] = {
  "White", "Red", "Green", "Blue", 
  "Cyan", "Yellow", "Magenta", "Black"
};

int delays[] = {1000, 800, 600, 400, 200};

int currentColor = 0;
int currentDelay = 0;

unsigned long lastColorPress = 0;
unsigned long lastDurationPress = 0;
const unsigned long debounceDelay = 50; // 50ms debounce window

void setup() {
  pinMode(colorBtn, INPUT);
  pinMode(durationBtn, INPUT);
  pinMode(redpin, OUTPUT);
  pinMode(greenpin, OUTPUT);
  pinMode(bluepin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  static bool lastColorBtnState = LOW;
  static bool lastDurationBtnState = LOW;

  bool colorBtnState = digitalRead(colorBtn);
  bool durationBtnState = digitalRead(durationBtn);

  unsigned long currentTime = millis();

  // Color Button Debounce
  if (colorBtnState == HIGH && lastColorBtnState == LOW && 
      currentTime - lastColorPress > debounceDelay) {
    
    currentColor = (currentColor + 1) % 7; // skip black
    displayColor(currentColor);
    Serial.print("Color: ");
    Serial.println(colorNames[currentColor]);
    lastColorPress = currentTime;
  }

  // Duration Button Debounce
  if (durationBtnState == HIGH && lastDurationBtnState == LOW &&
      currentTime - lastDurationPress > debounceDelay) {
    
    currentDelay = (currentDelay + 1) % 5;
    Serial.print("Duration: ");
    Serial.println(delays[currentDelay]);
    lastDurationPress = currentTime;
  }

  lastColorBtnState = colorBtnState;
  lastDurationBtnState = durationBtnState;

  delay(delays[currentDelay]);
}

void displayColor(int index) {
  digitalWrite(redpin, colors[index][0]);
  digitalWrite(greenpin, colors[index][1]);
  digitalWrite(bluepin, colors[index][2]);
}
