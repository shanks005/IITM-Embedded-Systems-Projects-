#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define CLOCK_FREQ 16000000UL
#define PRESCALER 256
#define TICK_US (PRESCALER * 1000000UL / CLOCK_FREQ) // 16µs per tick
#define MIN_PULSE_WIDTH 544
#define MAX_PULSE_WIDTH 2400

int servo1Pin = 11; // OC2A (PB3)
int servo2Pin = 3;  // OC2B (PD3)

/// @brief Constrains value within a range
int clip(int val, int min, int max)
{
    if (val < min)
        return min;
    if (val > max)
        return max;
    return val;
}

/// @brief Maps value from one range to another using clip
int map(int val, int in_low, int in_high, int out_low, int out_high)
{
    val = clip(val, in_low, in_high);
    return (val - in_low) * (out_high - out_low) / (in_high - in_low) + out_low;
}

/// @brief Generates PWM pulse with width in microseconds on D11 or D3
void servo_write_us(int pin, int micro_secs)
{
    int ticks = micro_secs / TICK_US;

    ticks = clip(ticks, MIN_PULSE_WIDTH / TICK_US, MAX_PULSE_WIDTH / TICK_US);

    if (pin == 11)
    {
        OCR2A = ticks;
    }
    else if (pin == 3)
    {
        OCR2B = ticks;
    }
}

/// @brief Converts angle to pulse width and calls servo_write_us()
void servo_write_angle(int pin, int angle)
{
    int pulse_width = map(angle, 0, 180, MIN_PULSE_WIDTH, MAX_PULSE_WIDTH);
    servo_write_us(pin, pulse_width);
}

int main()
{
    // ------------------------
    // TIMER2 CONFIG
    // ------------------------

    // Set Phase Correct PWM mode (WGM20 = 1, WGM21 = 0)
    TCCR2A |= (1 << WGM20);
    TCCR2A &= ~(1 << WGM21);
    TCCR2B &= ~(1 << WGM22);

    // Non-inverting PWM on OC2A and OC2B
    TCCR2A |= (1 << COM2A1) | (1 << COM2B1);
    TCCR2A &= ~((1 << COM2A0) | (1 << COM2B0));

    // Set prescaler to 256 → CS22=1, CS21=1, CS20=0
    TCCR2B |= (1 << CS22) | (1 << CS21);
    TCCR2B &= ~(1 << CS20);

    // Set D11 (PB3) and D3 (PD3) as output
    DDRB |= (1 << PB3); // D11 = OC2A
    DDRD |= (1 << PD3); // D3  = OC2B

    // ------------------------
    // SERVO TESTS
    // ------------------------

    while (1)
    {
        // Pulse width control
        servo_write_us(servo1Pin, MIN_PULSE_WIDTH);
        servo_write_us(servo2Pin, MAX_PULSE_WIDTH);
        _delay_ms(1000);

        servo_write_us(servo1Pin, MAX_PULSE_WIDTH);
        servo_write_us(servo2Pin, MIN_PULSE_WIDTH);
        _delay_ms(1000);

        // Angle control
        servo_write_angle(servo1Pin, 0);
        servo_write_angle(servo2Pin, 180);
        _delay_ms(1000);

        servo_write_angle(servo1Pin, 90);
        servo_write_angle(servo2Pin, 90);
        _delay_ms(1000);

        servo_write_angle(servo1Pin, 180);
        servo_write_angle(servo2Pin, 0);
        _delay_ms(1000);

        // Sweep motion
        for (int angle = 180; angle >= 0; angle--)
        {
            servo_write_angle(servo1Pin, angle);
            servo_write_angle(servo2Pin, 180 - angle);
            _delay_ms(10);
        }
        _delay_ms(500);

        for (int angle = 0; angle <= 180; angle++)
        {
            servo_write_angle(servo1Pin, angle);
            servo_write_angle(servo2Pin, 180 - angle);
            _delay_ms(10);
        }
        _delay_ms(500);
    }
}
