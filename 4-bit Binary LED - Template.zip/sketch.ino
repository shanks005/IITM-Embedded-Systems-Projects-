
int ledPin[] = {13, 12, 11,10};
int ledDelay[4]={8000, 4000,2000, 1000};
unsigned long lastchangetime[4]={0,0,0,0};
bool ledState[4]={LOW,LOW,LOW,LOW};

// declare other required variables

void setup() {
  for(int i=0;i<4;i++){
    pinMode(ledPin[i],OUTPUT);
    digitalWrite(ledPin[i],ledState[i]);
    // initialize lastChangeTimes
    // set pin mode for ledPins
  }
}
void loop() {
  unsigned long long currentTime=millis();
  for(int i=0;i<4;i++){
    if(currentTime-lastchangetime[i]>=ledDelay[i]){
      ledState[i]=!ledState[i];
      digitalWrite(ledPin[i],ledState[i]);
      lastchangetime[i]=currentTime;
    }
  }
  // implement the toggling logic
}
